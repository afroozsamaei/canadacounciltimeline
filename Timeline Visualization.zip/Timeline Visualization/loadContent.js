function loadStories() {

    $.getJSON("stories.json", function (json) {

        for (var i = 0; i < json.length; i++) {

            //Load Story Divs
            if (json[i].type == "story") {

                var blockDiv = document.createElement('div');
                blockDiv.className = "cd-timeline-block";
                blockDiv.id = "story " + json[i].year.toString();

                var imgDiv = document.createElement('div');
                imgDiv.className = "cd-timeline-img bounce-in";
                imgDiv.innerHTML = '<span class="e-date">' + json[i].year.toString() + '</span><span class="e-icon">!</span>';


                var textDiv = document.createElement('div');
                textDiv.className = "cd-timeline-content bounce-in";
                textDiv.innerHTML = '<h4 style="z-index: 1;">' + json[i].title + '</h4><center><img id = "image ' + json[i].image + '" src="fullimages/' + json[i].image + '.jpg"></center><p class="description" id="description ' + json[i].year + '" style="z-index: 1;">' + json[i].description + '</p><span class="cd-date">' + json[i].year.toString() + '</span>';

                //Load Milestone Divs
            } else {

                var blockDiv = document.createElement('div');
                blockDiv.className = "cd-timeline-block event";
                blockDiv.id = "milestone " + json[i].year.toString();

                var imgDiv = document.createElement('div');
                imgDiv.className = "cd-timeline-img bounce-in";
                imgDiv.innerHTML = '<span class="e-date">' + json[i].year.toString() + '</span><span class="e-icon">!</span>';

                var textDiv = document.createElement('div');
                textDiv.className = "cd-timeline-content bounce-in";
                textDiv.innerHTML = '<h4 style="z-index: 1;"></h4><p class="description" style="z-index: 1; display="block"">' + json[i].description + '</p><span class="cd-date">' + json[i].year.toString() + '</span>';

            }

            blockDiv.appendChild(imgDiv);
            blockDiv.appendChild(textDiv);
            document.getElementById("cd-timeline").appendChild(blockDiv);

        }


        var arrowDiv = document.createElement('div')
        arrowDiv.className = "arrow";
        arrowDiv.innerHTML = '<svg width="55px" height="30px" viewBox="0 0 55 30" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>Arrow Design</desc><defs></defs><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g transform="translate(-932.000000, -8362.000000)" fill-rule="nonzero" fill="#B64777"><g transform="translate(959.500000, 8377.000000) rotate(-270.000000) translate(-959.500000, -8377.000000) translate(944.500000, 8349.500000)"><path d="M29.4778905,28.2293558 L16.1403921,40.9062145 L2.8028937,53.5830733 C2.14373861,54.2199596 1.08226139,54.1962063 0.470612978,53.5355666 C0.164788772,53.2074737 0,52.8066361 0,52.3835298 L0,52.3835298 L0,27.0283277 L0,1.67312564 C0,0.754168432 0.754168432,0 1.67312564,0 C2.14373861,0 2.59208284,0.212295445 2.89790705,0.541872988 L16.1403921,13.1489563 L29.4778905,25.8258151 C30.1370456,26.4627014 30.1845523,27.4989407 29.5491505,28.1818491 C29.5253972,28.207087 29.5016439,28.207087 29.4778905,28.2293558 L29.4778905,28.2293558 Z" id="Shape"></path></g></g></g></svg>'

        document.getElementById("cd-timeline").appendChild(arrowDiv);
    });


    //Highlighting the bars as user scrolls
    var windowHeight = $(window).height(),
        divTop = windowHeight * .3,
        divBottom = windowHeight * .2;

    $(window).on('scroll', function () {
        var count = 0;
        // On each scroll check if div is in interested viewport
        $('.cd-timeline-block').each(function () {
            var thisTop = $(this).offset().top - $(window).scrollTop();
            var currentId = $(this)[0].id.replace(/^\D+/g, '');
            if (document.getElementById(currentId) != null) {
                   count += 1;
                if (thisTop <= divTop && (thisTop + $(this).height()) >= divBottom) {  
                    document.getElementById(currentId).style.fill = "#fad67b";
                    document.getElementById(currentId).style.transition = "all 0.2s";
                } else {
                    document.getElementById(currentId).style.fill = "#002060";
                    document.getElementById(currentId).style.transition = "all 0.2s";
                }
            }
        });
    });

}
