function barGraph() {

    var margin = {
            top: 0.02 * window.innerWidth,
            right: 0.02 * window.innerWidth,
            bottom: 0.02 * window.innerWidth,
            left: 0.05 * window.innerWidth
        },
        width = Math.max(window.innerWidth,1000) - margin.left - margin.right,
        height = Math.min(window.innerHeight / 5, 190) - margin.top - margin.bottom;


    var x = d3.scale.ordinal()
        .rangeRoundBands([0, width], .15);

    var y = d3.scale.linear()
        .range([height, 0]);

    var xAxis = d3.svg.axis()
        .scale(x)
        .orient("bottom");

    var yAxis = d3.svg.axis()
        .scale(y)
        .orient("left")

    yAxis.ticks(5)

    var tip = d3.tip()
        .attr('class', 'd3-tip')
        .offset([-10, 0])
        .html(function (d) {
            return "<p style = 'text-align: center;'><strong>" + d.year + "</strong></p><strong>Funding:</strong> <span style='color:#002060'>" + "$" + (d.funding).toFixed(1) + "</span>" + " M";
        })

    var svg = d3.select("#chart").append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.call(tip);

    d3.json("fundingData.json", function (error, data) {
        x.domain(data.map(function (d) {
            if (d.funding != 0) {
                return d.year;
            }
        }));
        y.domain([0, d3.max(data, function (d) {
            return d.funding;
        })]);

        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis)

        svg.append("g")
            .attr("class", "y axis")
            .call(yAxis)


            .append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", -40)
            .attr("dy", ".71em")
            .style("text-anchor", "end")
            .text("Funding (million $)")


        d3.selectAll("#chart")
            .style("font-size", ".6vw")

        svg.selectAll(".bar")
            .data(data)
            .enter().append("rect")
            .attr("class", "bar")
            .attr("id", function (d) {
                return String(d.year);
            })
            .attr("x", function (d) {
                return x(d.year);
            })
            .attr("width", x.rangeBand())
            .style("fill", "#002060")
            .attr("y", height)
            .attr("height", 0)
            .transition()
            .duration(1000)
            .attr("y", function (d) {
                return y(d.funding);
            })
            .attr("height", function (d) {
                return height - y(d.funding);
            })



        d3.selectAll(".bar")
            .on('mouseover', function (d) {
                tip.show(d)
                document.getElementById(String(d.year)).style.fill = "#fad67b";
                document.getElementById(String(d.year)).style.transition = "all 0.2s";
            })
            .on('mouseout', function (d) {
                tip.hide(d)
                document.getElementById(String(d.year)).style.fill = "#002060";
                document.getElementById(String(d.year)).style.transition = "all 0.2s";
            })


        d3.selectAll(".bar").on("touchstart", function (d) {
            tip.show(d)
            setTimeout(function () {
                tip.hide(d)
            }, 5000);
        })


        d3.selectAll(".bar").on('click', function () {

            tip.hide();

            var test = false;
            var id = this.id;
            var blocks = [];
            var scrollPos;

            $('.cd-timeline-block').each(function () {
                blocks.push($(this));
            });


            for (var i = 0; i < blocks.length; i++) {
                if (blocks[i][0].id.replace(/^\D+/g, '') === id) {
                    scrollPos = blocks[i].offset().top - 10;
                    test = true;
                    break;
                }
            }

            //Scroll to previous divs if selected year does not have stories
            if (!test) {
                var y = Number(id)
                while (!test) {
                    y -= 1;
                    for (var i = 0; i < blocks.length; i++) {
                        if (blocks[i][0].id.replace(/^\D+/g, '') === String(y)) {
                            var scrollPos = blocks[i].offset().top - 10;
                            test = true;
                            break;
                        }
                    }
                }
            }

            $('html, body').animate({
                scrollTop: scrollPos
            }, 1500);

        });

        d3.select(window).on('resize', function () {
            if (window.innerWidth > "770") {

                d3.select("#chart").selectAll("*").remove();
                barGraph();
            }
        });

        window.addEventListener('orientationchange', function () {
            location.reload();
        });


    })


    function type(d) {
        d.funding = +d.funding;
        return d;
    }

}
